<?php
/**
 * Motta Addons Modules functions and definitions.
 *
 * @package Motta
 */

namespace Motta\Addons\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Builder {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	private static $is_product_elementor;

	private static $load_single_product_default;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->load_product();
		add_action('init', array( $this, 'actions'), 1);
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\Motta\Addons\Auto_Loader::register( [
			'Motta\Addons\Elementor\Builder\Settings'    	=> MOTTA_ADDONS_DIR . 'inc/elementor/builder/inc/settings.php',
			'Motta\Addons\Elementor\Builder\Post_Type'    	=> MOTTA_ADDONS_DIR . 'inc/elementor/builder/inc/post-type.php',
			'Motta\Addons\Elementor\Builder\Frontend'    	=> MOTTA_ADDONS_DIR . 'inc/elementor/builder/inc/frontend.php',
			'Motta\Addons\Elementor\Builder\Widgets'    	=> MOTTA_ADDONS_DIR . 'inc/elementor/builder/inc/widgets.php',
			'Motta\Addons\Elementor\Builder\Widgets'    	=> MOTTA_ADDONS_DIR . 'inc/elementor/builder/inc/widgets.php',
			'Motta\Addons\Elementor\Builder\Elementor_Settings' => MOTTA_ADDONS_DIR . 'inc/elementor/builder/inc/elementor-settings.php',
		] );

	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		if( is_admin() ) {
			\Motta\Addons\Elementor\Builder\Settings::instance();
		}

		if( $this->is_product_elementor() ) {
			\Motta\Addons\Elementor\Builder\Post_Type::instance();
			\Motta\Addons\Elementor\Builder\Frontend::instance();
			\Motta\Addons\Elementor\Builder\Widgets::instance();

			if( class_exists('Elementor\Core\Base\Module') ) {
				\Motta\Addons\Elementor\Builder\Elementor_Settings::instance();
			}
		}
	}

	public function is_product_elementor() {
		if ( isset( self::$is_product_elementor ) ) {
			return self::$is_product_elementor;
		}

		self::$is_product_elementor = true;
		if( ! class_exists('\Elementor\Plugin') ) {
			self::$is_product_elementor = false;
		}

		if( ! get_option('motta_builder_enable', false) ) {
			self::$is_product_elementor = false;
		}

		return self::$is_product_elementor;
	}


	private function load_product() {
		add_filter('motta_load_single_product_layout', array( $this, 'load_motta_single_layout' ) );
		add_filter('motta_get_single_product_settings', array( $this, 'load_motta_single_layout' ) );
		add_filter('motta_change_compare_button_settings', array( $this, 'load_motta_single_layout' ) );
		add_filter('motta_change_wishlist_button_settings', array( $this, 'load_motta_single_layout' ) );
	}

	public function load_motta_single_layout() {
		if ( isset( self::$load_single_product_default ) ) {
			return self::$load_single_product_default;
		}
		self::$load_single_product_default = false;

		if( ! get_option('motta_builder_enable', false) ) {
			self::$load_single_product_default = true;
		} else {
			if( empty(\Motta\Addons\Elementor\Builder\Frontend::get_product_template_id()) ) {
				self::$load_single_product_default = true;
			}
		}

		return self::$load_single_product_default;
	}
}
